// &#65 &#90
const mainSec = document.querySelector("#main");

function createAlphabet () {
    for (let i = 65; i<91; i++) {
        const newBox = document.createElement("div");
        newBox.classList.add("box");
        const p = document.createElement("span");
        p.appendChild(document.createTextNode(` &#${i};`))
        newBox.appendChild(p);
        mainSec.appendChild(newBox);
        newBox.addEventListener('dragstart', dragStart);
        newBox.setAttribute("draggable", true);
        newBox.setAttribute("id",`&#${i};`)
    }
}

function dragStart (e) {
    e.dataTransfer.setData("text/plain", e.target.id);
    console.log(e);
    console.log(e.target.id);
}

function dragOver (e) {
    e.preventDefault();
}

function drop (e) {
    e.preventDefault();
    const data = e.dataTransfer.getData("text/plain");
    const movedBox = document.getElementById(data);
    console.log(data);
    e.target.appendChild(movedBox);
}

mainSec.addEventListener("dragover", dragOver);
mainSec.addEventListener("drop", drop);

createAlphabet ();