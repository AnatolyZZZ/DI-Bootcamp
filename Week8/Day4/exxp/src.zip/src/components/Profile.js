const Profile = (props) => {
    return <h1>Profile screen</h1>
}

export default Profile