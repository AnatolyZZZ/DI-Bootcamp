const Shop = (props) => {
    throw new Error ('Error')
    return (
        <h1>Home</h1>
    )
}
export default Shop